package exercici1;

/**
 *
 * @author bort
 */
public interface Figura2D {
    public String area();
    
    public String perímetre();
}
