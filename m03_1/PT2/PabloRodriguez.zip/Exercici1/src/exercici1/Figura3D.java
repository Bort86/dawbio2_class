package exercici1;

/**
 *
 * @author Pablo Rodriguez
 */
public interface Figura3D {
    public String volum();
}
