import { ItemValidatorDirective } from './item-validator.directive';

describe('ItemValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ItemValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
