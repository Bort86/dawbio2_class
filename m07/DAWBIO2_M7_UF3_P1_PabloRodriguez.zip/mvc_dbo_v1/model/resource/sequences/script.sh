sudo mount -t vboxsf -o uid=$UID,gid=$(id -g) Daw2bio /home/bort/Escritorio/USB
