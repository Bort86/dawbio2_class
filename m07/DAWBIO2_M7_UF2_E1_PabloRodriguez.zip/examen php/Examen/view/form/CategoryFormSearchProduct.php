<div id="content">
    <form method="post" action="">
        <fieldset>
            <legend>Search products by category</legend>
            <label>Name *:</label>
            <input type="text" placeholder="Name" name="name" />

            <label>* Required fields</label>
            <button type="submit" name="action" value="list_products">list products</button>
        </fieldset>
    </form>
</div>
