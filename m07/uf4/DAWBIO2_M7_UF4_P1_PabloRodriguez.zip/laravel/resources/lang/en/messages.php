<?php
//English

return [
    'cats' => 'Categories', 
    'create_ok' => 'Data created succesfully',
];