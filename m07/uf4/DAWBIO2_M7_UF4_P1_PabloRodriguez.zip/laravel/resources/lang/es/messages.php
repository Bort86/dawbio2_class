<?php
//Spanish

return [
    'cats' => 'Categorias', 
    'create_ok' => 'Data creada correctamente',
];