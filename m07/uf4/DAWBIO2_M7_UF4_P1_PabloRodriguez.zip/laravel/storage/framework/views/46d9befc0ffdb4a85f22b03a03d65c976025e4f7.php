<?php /* /home/bort/Escritorio/m07/uf4/laravel/resources/views/product/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header text-center">
        Create Product
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(url('/product/create')); ?>">
            
            
            <?php echo e(method_field('POST')); ?>

            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="name">Name *:</label>
                <input class="form-control" type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" />
                <label for="description">Description:</label>
                <textarea class="form-control" id="description" name="description"><?php echo e(old('description')); ?></textarea>
                <label for="price">Price *:</label>
                <input class="form-control" type="text" id="price" name="price" value="<?php echo e(old('price')); ?>" />
                <label for="category_id">Category *:</label>
                <select name="category_id" id="category_id">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

            <div class="form-group">
                <button class="btn btn-success" type="submit">create</button>
                <button class="btn btn-danger" type="reset">reset</button>
                <a class="btn btn-dark" href="<?php echo e(route('productcreate')); ?>">reload</a>
                <a class="btn btn-info" href="<?php echo e(url('/product/list')); ?>">return list</a>
            </div>

            <label class="alert alert-light">* Required fields</label>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('message'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php if(isset($message)): ?>
<div class="alert alert-warning">
    <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>