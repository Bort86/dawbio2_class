/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Pablo Rodriguez
 */
public class Vista extends JFrame{
    
    public JButton btEuros, btMoneda;
    public JPanel panelBotones, panelResult;
    public JLabel lResultado, lText;
    public JTextField campoTexto;
    
    public Vista(){
        getContentPane().setLayout(new BorderLayout());
        
        panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout());
        
        panelResult = new JPanel();
        panelResult.setLayout(new FlowLayout());
        
        btEuros = new JButton("Convertir a Euros");
        btMoneda = new JButton("Convertir a Moneda");
        
        lText= new JLabel("Resultado: ");
        lResultado = new JLabel();
        campoTexto = new JTextField(20);
        
        panelBotones.add(btEuros);
        panelBotones.add(btMoneda);
        
        panelResult.add(lText);
        panelResult.add(lResultado);
        
        add(campoTexto, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.SOUTH);
        add(panelResult, BorderLayout.CENTER);
                
    }
}
